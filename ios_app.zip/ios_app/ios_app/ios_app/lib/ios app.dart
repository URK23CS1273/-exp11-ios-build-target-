import 'package:flutter/material.dart';

void main() {
  runApp(const IOSApp());
}

class IOSApp extends StatelessWidget {
  const IOSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'iOS Flutter Application',
      theme: ThemeData(fontFamily: 'Arial', useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = '✓ Application Ready';

  void testButton() {
    setState(() {
      status = '✓ Button clicked successfully';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Button clicked successfully'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3E6F6),

      // Top purple bar
      appBar: AppBar(
        backgroundColor: const Color(0xFF7038C5),
        elevation: 0,
        centerTitle: true,
        toolbarHeight: 32,
        title: const Text(
          'iOS Flutter Application',
          style: TextStyle(
            color: Colors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: Center(
        child: Container(
          width: 112,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 5,
                spreadRadius: 1,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // iPhone icon
              const Icon(
                Icons.phone_iphone,
                color: Color(0xFF7038C5),
                size: 30,
              ),

              const SizedBox(height: 4),

              // Main title
              const Text(
                'Flutter iOS App',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF7038C5),
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 3),

              // Experiment number
              const Text(
                'Experiment 11',
                style: TextStyle(color: Colors.grey, fontSize: 7),
              ),

              const Text(
                'Add iOS as a Build Target',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 6.5),
              ),

              const SizedBox(height: 7),

              // Test Button
              SizedBox(
                height: 21,
                child: ElevatedButton(
                  onPressed: testButton,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF7038C5),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Test Button',
                    style: TextStyle(fontSize: 7, fontWeight: FontWeight.bold),
                  ),
                ),
              ),

              const SizedBox(height: 7),

              // Status
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFD8F5D8),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.green,
                    fontSize: 6,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
